users_passwords = {"JavierAdmin": "1234",
                   "PacoUser1": "4321",
                   "Kiko": "9531"}

for x in users_passwords:
    print(users_passwords[x])
    print(x)
    print(users_passwords)