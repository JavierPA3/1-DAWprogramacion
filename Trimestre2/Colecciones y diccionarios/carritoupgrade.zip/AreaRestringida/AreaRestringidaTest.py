"""
Test del area restringida.


"""

from AreaRestringida import AreaRestringida

a1 = AreaRestringida()
a1.access()
