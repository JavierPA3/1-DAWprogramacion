"""
7. Una empresa de venta por internet de productos electrónicos nos ha encargado implementar un carrito de la compra.
Crea la clase Carrito. Al carrito se le pueden ir agregando elementos que se guardarán en una lista, por tanto, deberás
crear la clase Elemento. Cada elemento del carrito deberá contener el nombre del producto, su precio y la cantidad
(número de unidades de dicho producto). A continuación se muestra tanto el contenido del programa principal como la
salida que debe mostrar el programa. Los métodos a implementar se pueden deducir del programa principal.

Autor: Javier Postigo Arévalo
Fecha: 12/03/2023
"""
from elementos import Elemento


class Carrito:

    def __init__(self):
        self.list = []

    def agrega(self, elements: Elemento):
        self.list.append(elements)

    def list_to_print(self):
        print("Contenido del carrito")
        print("------------------------")
        for x in range(0, len(self.list)):
            x1: Elemento = self.list[x]
            print(f"{x1.card} PVP: {x1.amount} Unidades: {x1.cuantity} subtotal {x1.amount * x1.cuantity}")
        return ""

    def numero_elementos(self):
        return f"Hay {len(self.list)} productos en el carrito"

    def importe_total(self):
        global_balance = 0
        for x in range(0, len(self.list)):
            x1: Elemento = self.list[x]
            global_balance += x1.amount
        return global_balance

    def check_if_product_already_exist(self, elements: Elemento):
        if len(self.list) > 0:
            for x in range(0, len(self.list)):
                x1: Elemento = self.list[x]
                if x1.card == elements.card:
                    x1.cuantity += 1

    def __str__(self):
        return f"{self.list_to_print()}"
