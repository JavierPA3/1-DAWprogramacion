"""

Test clase country quizz
"""

from Country_quizz import CountryQuizz

c1 = CountryQuizz()

c1.country_quizz()