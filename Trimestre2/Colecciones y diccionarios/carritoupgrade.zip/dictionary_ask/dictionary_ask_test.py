"""
tEST DE LA CLASE DICTIONARY ASK

"""

from Dictionary_ask import Dictionary

d1 = Dictionary()
d1.ask_traduction_to_user()

