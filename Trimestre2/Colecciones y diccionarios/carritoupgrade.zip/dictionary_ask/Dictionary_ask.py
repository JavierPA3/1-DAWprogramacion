"""
4. Realiza un programa que escoja al azar 5 palabras en español del mini-diccionario del ejercicio anterior.
El programa irá pidiendo que el usuario teclee la traducción al inglés de cada una de las palabras y comprobará si
son correctas. Al final, el programa deberá mostrar cuántas respuestas son válidas y cuántas erróneas.

Autor: Javier Postigo Arévalo
Fecha: 04/03/2023
"""
import random


class Dictionary:

    dictionary = {"uno": "one",
                  "dos": "two",
                  "tres": "three",
                  "cuatro": "four",
                  "cinco": "five",
                  "seis": "six",
                  "siete": "seven",
                  "ocho": "eight",
                  "nueve": "nine",
                  "diez": "ten",
                  "once": "eleven",
                  "doce": "twelve",
                  "trece": "thirteen",
                  "catorce": "fourteen",
                  "quince": "fifteen",
                  "dieciseis": "sixteen",
                  "diecisiete": "seventeen",
                  "dieciocho": "eighteen",
                  "diecinueve": "nineteen",
                  "veinte": "twenty"}

    @staticmethod
    def ask_traduction_to_user():
        all_time_cont = 0
        ai_election = 0
        while all_time_cont != 5:
            random_number = random.randint(1, 20)
            cont = 1
            for_cont = 0
            for x in Dictionary.dictionary:
                if for_cont == random_number:
                    ai_election = x
                for_cont += 1
            while True:
                user_election = input(f"Digame la traducción de {ai_election}: ")
                if user_election == Dictionary.dictionary[ai_election]:
                    print(f"Ha ganado en {cont} turnos.")
                    break
                else:
                    print("Respuesta incorrecta")
                    cont += 1
            all_time_cont += 1
