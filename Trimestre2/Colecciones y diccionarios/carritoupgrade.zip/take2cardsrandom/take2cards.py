"""
2. Realiza un programa que escoja al azar 10 cartas de la baraja española (10 objetos de la clase Carta).
Emplea una lista para almacenarlas y asegúrate de que no se repite ninguna. Las cartas se deben mostrar ordenadas.
Primero se ordenarán por palo (bastos, copas, espadas, oros) y cuando coincida el palo, se ordenará por número: as,
2, 3, 4, 5, 6, 7, sota, caballo, rey.

Autor: Javier Postigo Arévalo
Fecha: 12/03/2023
"""
from SegundoTrimestre.POOTanda3.cards.card import Card
import random


class RandomCards:

    def __init__(self):
        self.numbers = "1 2 3 4 5 6 7 8 9 SOTA CABALLO REY".split()
        self.suits = "OROS COPAS ESPADAS BASTOS".split()
        self.cards = [Card(n, s) for s in self.suits for n in self.numbers]

    def random_card(self):
        random_number = random.randint(1, 12)
        return self.cards[random_number]
