"""
Test de la clase diccionario

"""

from Dictionary import Dictionary

d1 = Dictionary()

d1.ask_meaning()
