"""
3. Crea un mini-diccionario español-inglés que contenga, al menos, 20 palabras (con su correspondiente traducción).
Utiliza un diccionario para almacenar las parejas de palabras. El programa pedirá una palabra en español y dará la
correspondiente traducción en inglés.

Autor: Javier Postigo Arévalo
Fecha: 04/03/2023
"""


class Dictionary:

    dictionary = {"uno": "one",
                  "dos": "two",
                  "tres": "three",
                  "cuatro": "four",
                  "cinco": "five",
                  "seis": "six",
                  "siete": "seven",
                  "ocho": "eight",
                  "nueve": "nine",
                  "diez": "ten",
                  "once": "eleven",
                  "doce": "twelve",
                  "trece": "thirteen",
                  "catorce": "fourteen",
                  "quince": "fifteen",
                  "dieciseis": "sixteen",
                  "diecisiete": "seventeen",
                  "dieciocho": "eighteen",
                  "diecinueve": "nineteen",
                  "veinte": "twenty"}

    @staticmethod
    def ask_meaning():
        is_in_dictionary = False
        while True:
            meaning_asked_by_user = input("¿Cual es la palabra que quieres saber el significado? ")
            for x in Dictionary.dictionary:
                if x == meaning_asked_by_user:
                    print(f"{Dictionary.dictionary[x]}")
                    is_in_dictionary = True
            if not is_in_dictionary:
                print("No está en el diccionario")
            want_to_continue = input("Want to continue? s/n. ")
            if want_to_continue.lower() == "n":
                break
        print("Nos vemos ;)")
        return None
