"""
Clase elemento

"""


class Elemento:

    def __init__(self, shop_element: str, amount: float, cuantity: int):
        self.shop_element = shop_element
        self.__amount = amount
        self.__cuantity = cuantity

    @property
    def card(self):
        return self.shop_element

    @property
    def amount(self):
        return self.__amount

    @property
    def cuantity(self):
        return self.__cuantity

    def __repr__(self):
        return f"{self.__class__},{self.card},{self.amount},{self.cuantity}. "
